import { Check, X } from 'lucide-react';
import { ABOUT } from '../../data/content';
import Container from '../ui/Container';
import Reveal from '../ui/Reveal';
import SectionHeading from '../ui/SectionHeading';

function CompareList({ title, items, positive }) {
  const Mark = positive ? Check : X;
  return (
    <div className={positive ? 'rounded-2xl bg-ink p-6 text-slip sm:p-7' : 'rounded-2xl border border-ink/15 bg-white p-6 sm:p-7'}>
      <h3 className="text-lg font-semibold">{title}</h3>
      <ul className="mt-4 space-y-3">
        {items.map((item) => (
          <li key={item} className="flex items-start gap-3 text-[15px] leading-snug">
            <Mark
              size={18}
              aria-hidden="true"
              className={positive ? 'mt-0.5 shrink-0 text-ochre' : 'mt-0.5 shrink-0 text-ink/40'}
            />
            <span className={positive ? '' : 'text-ink/65'}>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function About() {
  return (
    <section id="about" aria-labelledby="about-title" className="scroll-mt-20 py-20 sm:py-28">
      <Container className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        <Reveal>
          <SectionHeading id="about-title" title={ABOUT.title} />
          <div className="mt-6 max-w-xl space-y-4 text-lg leading-relaxed text-ink/70">
            {ABOUT.paragraphs.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
        </Reveal>

        <Reveal delay={120} className="grid gap-4 sm:grid-cols-2">
          <CompareList title="Before Kiln" items={ABOUT.before} />
          <CompareList title="With Kiln" items={ABOUT.after} positive />
        </Reveal>
      </Container>
    </section>
  );
}
