import { cn } from '../../lib/cn';

export default function Container({ className, children, ...props }) {
  return (
    <div className={cn('mx-auto w-full max-w-6xl px-5 sm:px-8', className)} {...props}>
      {children}
    </div>
  );
}
