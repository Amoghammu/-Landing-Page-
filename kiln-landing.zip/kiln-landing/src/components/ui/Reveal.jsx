import { useEffect, useRef, useState } from 'react';
import { cn } from '../../lib/cn';

/** Fades its children in once, the first time they scroll into view. */
export default function Reveal({ as: Tag = 'div', delay = 0, className, children, ...props }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    if (!('IntersectionObserver' in window)) {
      setVisible(true);
      return undefined;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <Tag
      ref={ref}
      style={{ '--delay': `${delay}ms` }}
      className={cn('reveal', visible && 'is-visible', className)}
      {...props}
    >
      {children}
    </Tag>
  );
}
