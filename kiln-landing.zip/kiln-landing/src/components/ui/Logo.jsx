export default function Logo({ className = '' }) {
  return (
    <a href="#top" className={`inline-flex items-center gap-2.5 ${className}`} aria-label="Kiln home">
      <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true">
        <rect width="32" height="32" rx="8" fill="#2F4FA8" />
        <path d="M8 25V15a8 8 0 0 1 16 0v10z" fill="#F2F4F1" />
        <path d="M12.5 25v-5a3.5 3.5 0 0 1 7 0v5z" fill="#E3A72F" />
      </svg>
      <span className="font-display text-xl font-bold tracking-tight">Kiln</span>
    </a>
  );
}
