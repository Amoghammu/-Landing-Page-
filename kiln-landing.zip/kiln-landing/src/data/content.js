export const NAV_LINKS = [
  { label: 'About', href: '#about' },
  { label: 'Features', href: '#features' },
  { label: 'How it works', href: '#how-it-works' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Pricing', href: '#pricing' },
];

export const ABOUT = {
  title: 'Made by a studio manager who ran out of sticky notes',
  paragraphs: [
    'Kiln started in a shared pottery studio with a paper firing log, a group chat for class waitlists, and a spreadsheet nobody trusted. Pieces went missing. Members double-booked wheels. Every Friday firing began with an argument about what was already on the shelves.',
    'Kiln puts bookings, memberships and every piece you fire in one place, so your team spends the day teaching and making instead of chasing information.',
  ],
  before: [
    'Waitlists in a group chat',
    'A paper log taped to the kiln',
    'Pickup reminders sent by hand',
    'Membership renewals tracked in a spreadsheet',
  ],
  after: [
    'Waitlists that fill open spots automatically',
    'A live firing board for every kiln',
    'Pickup texts sent when a piece cools',
    'Renewals and shelf rentals handled for you',
  ],
};

export const FEATURES = [
  {
    icon: 'CalendarCheck',
    title: 'Class and workshop booking',
    text: 'Sell drop-in sessions, six-week courses and private parties from one page. Waitlists fill cancelled spots on their own, and students get reminders before every session.',
    tags: ['Drop-in', 'Courses', 'Workshops', 'Parties'],
    wide: true,
    tone: 'ink',
  },
  {
    icon: 'Users',
    title: 'Memberships and shelf rental',
    text: 'Monthly plans, open-studio hours and assigned shelves, with renewals and failed payments handled automatically.',
    tone: 'white',
  },
  {
    icon: 'Flame',
    title: 'Firing tracker',
    text: 'See every piece move from greenware to bisque to glazed to fired, across every kiln you own.',
    tone: 'white',
  },
  {
    icon: 'Palette',
    title: 'Glaze library',
    text: 'Keep recipes, cone ranges and test tiles together. Members pick a glaze when they load a piece, and your firing notes follow it to the kiln.',
    wide: true,
    tone: 'celadon',
  },
  {
    icon: 'BellRing',
    title: 'Pickup notices',
    text: 'Makers get a text the moment a piece is unloaded and cool enough to collect.',
    tone: 'white',
  },
  {
    icon: 'BarChart3',
    title: 'Studio reports',
    text: 'Clay sold, kiln hours used and class fill rates, ready for your accountant.',
    tone: 'white',
  },
  {
    icon: 'CreditCard',
    title: 'Waivers and payments',
    text: 'Digital waivers, card and bank payments, and refunds without leaving the page.',
    tone: 'white',
  },
];

export const STEPS = [
  {
    icon: 'Store',
    title: 'Set up your studio',
    text: 'Add your rooms, kilns, instructors and clay prices. Most studios finish in an afternoon.',
  },
  {
    icon: 'CalendarPlus',
    title: 'Open your bookings',
    text: 'Publish classes and memberships on a page that matches your studio, then share the link.',
  },
  {
    icon: 'Flame',
    title: 'Load the kiln',
    text: 'Scan or tap each piece as it goes on the shelf. Kiln tracks it through every firing stage.',
  },
  {
    icon: 'PackageCheck',
    title: 'Let makers know',
    text: 'When a piece is ready, its maker gets a pickup text. You get the shelf back.',
  },
];

export const TESTIMONIALS = [
  {
    quote:
      'We used to lose about four pieces a month between the wheel and the kiln. Since switching to Kiln, we have lost none, and our Friday firing takes half the time to load.',
    name: 'Dana Whitfield',
    role: 'Owner, Slow Hands Ceramics',
    featured: true,
  },
  {
    quote:
      'Waitlists alone paid for the subscription. Cancelled spots refill before I even see the notification.',
    name: 'Rohan Mehta',
    role: 'Studio manager, Terra & Tide',
  },
  {
    quote:
      'Our members love the pickup texts. I love that nobody asks me whether their mug is done anymore.',
    name: 'Camille Laurent',
    role: 'Instructor, Atelier Cinq',
  },
];

export const PLANS = [
  {
    name: 'Starter',
    price: 29,
    description: 'For home studios and teachers just getting going.',
    features: [
      'Up to 40 students a month',
      '1 kiln in the firing tracker',
      'Class booking page',
      'Email reminders',
    ],
    cta: 'Start free trial',
  },
  {
    name: 'Studio',
    price: 59,
    description: 'For community studios running classes and memberships.',
    features: [
      'Unlimited students',
      'Up to 4 kilns',
      'Memberships and shelf rental',
      'Pickup texts and waitlists',
      'Glaze library',
    ],
    cta: 'Start free trial',
    popular: true,
  },
  {
    name: 'Collective',
    price: 119,
    description: 'For multi-location studios and ceramics schools.',
    features: [
      'Everything in Studio',
      'Unlimited kilns and locations',
      'Staff roles and permissions',
      'Studio reports and exports',
      'Priority phone support',
    ],
    cta: 'Talk to us',
  },
];

export const FOOTER_LINKS = [
  {
    title: 'Product',
    links: [
      { label: 'Features', href: '#features' },
      { label: 'How it works', href: '#how-it-works' },
      { label: 'Pricing', href: '#pricing' },
      { label: 'Changelog', href: '#' },
    ],
  },
  {
    title: 'Company',
    links: [
      { label: 'About', href: '#about' },
      { label: 'Customers', href: '#reviews' },
      { label: 'Careers', href: '#' },
      { label: 'Contact', href: '#contact' },
    ],
  },
  {
    title: 'Resources',
    links: [
      { label: 'Help centre', href: '#' },
      { label: 'Glaze guides', href: '#' },
      { label: 'Studio handbook', href: '#' },
      { label: 'Privacy', href: '#' },
    ],
  },
];
