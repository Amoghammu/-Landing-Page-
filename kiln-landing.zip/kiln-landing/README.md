# Kiln landing page

A responsive landing page for "Kiln", a fictional studio-management product for pottery studios.
Built with React 18, Vite and Tailwind CSS 3.

## Open in VS Code

1. Install Node.js (v18 or newer) from https://nodejs.org.
2. Unzip, then in VS Code choose **File > Open Folder** and select the `kiln-landing` folder.
3. Accept the "install recommended extensions" prompt (Tailwind CSS IntelliSense).
4. Open the terminal (**Ctrl+`**) and run `npm install`, then `npm run dev`.
   Or press **Ctrl+Shift+B** to start the dev server (run the "Install dependencies" task once first).
5. Open http://localhost:5173.

Shortcut: double-click `start.bat` (Windows) or run `./start.sh` (Mac/Linux). It installs and starts everything.

## Run it

```bash
npm install
npm run dev      # http://localhost:5173
npm run build    # production build in dist/
npm run preview  # serve the production build
```

## Structure

```
src/
  App.jsx                 Page composition
  index.css               Tailwind layers, base styles, reveal + reduced-motion rules
  data/content.js         All copy, plans, steps and links (edit text here)
  hooks/                  useScrolled, useScrollSpy
  lib/cn.js               Class-name helper
  components/
    ui/                   Reusable pieces: Button, Container, Reveal, SectionHeading,
                          Logo, Icon, SocialIcons, KilnLoad (interactive hero visual)
    sections/             Navbar, Hero, About, Features, HowItWorks,
                          Testimonials, Pricing, Footer
```

## Customising

- Colours and fonts live in `tailwind.config.js` (`slip`, `ink`, `cobalt`, `celadon`, `ochre`).
- Change product name, copy, prices and links in `src/data/content.js`.
- Replace social and footer `href="#"` placeholders with real URLs.
